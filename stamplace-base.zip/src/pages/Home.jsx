import LoginForm from '../components/LoginForm';

export default function Home() {
  return (
    <div>
      <h1>Welcome to Merkaz HaStam Haolami</h1>
      <LoginForm />
    </div>
  );
}

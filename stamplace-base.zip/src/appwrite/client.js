import { Client } from 'appwrite';

const client = new Client();

const endpoint = import.meta.env.VITE_APPWRITE_ENDPOINT;
if (!endpoint) {
  throw new Error("Missing VITE_APPWRITE_ENDPOINT");
}
client.setEndpoint(endpoint)
      .setProject(import.meta.env.VITE_APPWRITE_PROJECT_ID);

export default client;

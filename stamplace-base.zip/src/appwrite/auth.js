import { Account } from 'appwrite';
import client from './client';

const account = new Account(client);

export const createSession = async (email, password) =>
  await account.createEmailSession(email, password);

export const getAccount = async () => await account.get();

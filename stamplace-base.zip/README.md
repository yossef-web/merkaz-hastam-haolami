# Merkaz HaStam Haolami

This repository is the core of the GPT-powered FinTech Marketplace for certified Sofer Stam.

## Setup

1. Copy `.env.example` to `.env` and fill in your project-specific variables.
2. Run:

```bash
npm install
npm run dev
```

3. To verify setup, use:

```bash
node preflightCheck.js
```

